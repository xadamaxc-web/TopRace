package com.toprace.tracker.ui

import androidx.compose.runtime.getValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import com.toprace.tracker.logic.Analysis
import com.toprace.tracker.logic.AnalysisEngine
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.toprace.tracker.Car
import com.toprace.tracker.Defaults
import com.toprace.tracker.Road
import com.toprace.tracker.db.LearnedStats
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings

class SetupState {
    var balance by mutableStateOf("")
    var slot by mutableStateOf(0) // 0 = none, 1..3
    var road by mutableStateOf<Road?>(null)
    val cars = mutableStateListOf<Car>() // pick order
    var analyzing by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var minimized by mutableStateOf(false)

    // post-race
    var postRace by mutableStateOf(false)
    val hidden = mutableStateListOf<Road>()
    var oddText by mutableStateOf("")
    var loseWinner by mutableStateOf<Car?>(null)
    var outcome by mutableStateOf<String?>(null) // W1 / W2 / W3 / LOSE

    // loaded from Room by OverlayService
    var settings by mutableStateOf(StrategySettings())
    var stats by mutableStateOf<List<LearnedStats>>(emptyList())
    var rounds by mutableStateOf<List<RoundEntity>>(emptyList()) // newest first

    val maxBet: Double get() = (balance.toDoubleOrNull() ?: 0.0) * Defaults.MAX_BET_FRACTION
    val ready: Boolean get() = road != null && cars.size == Defaults.PICKS_REQUIRED

    fun toggleCar(car: Car) {
        if (car in cars) cars.remove(car)
        else if (cars.size < Defaults.PICKS_REQUIRED) cars.add(car)
    }

    fun currentAnalysis(): Analysis? {
        val r = road ?: return null
        if (cars.size != Defaults.PICKS_REQUIRED) return null
        return AnalysisEngine.analyze(r, slot, cars.toList(), settings, stats, rounds, maxBet)
    }

    fun outcomeIndex(): Int = when (outcome) { "W1" -> 0; "W2" -> 1; "W3" -> 2; else -> -1 }

    fun openPostRace(label: String) {
        outcome = label
        hidden.clear()
        loseWinner = null
        val idx = outcomeIndex()
        oddText = if (idx >= 0) {
            currentAnalysis()?.picks?.getOrNull(idx)?.let { String.format(Locale.US, "%.1f", it.odd) } ?: ""
        } else ""
        postRace = true
    }

    fun applyNet(net: Double) {
        val b = balance.toDoubleOrNull() ?: return
        balance = String.format(Locale.US, "%.2f", b + net).removeSuffix(".00")
    }

    fun toJson(): String = JSONObject().apply {
        put("balance", balance)
        put("slot", slot)
        put("road", road?.name ?: "")
        put("cars", JSONArray(cars.map { it.name }))
        put("screen", if (postRace) 2 else if (analyzing) 1 else 0)
        put("outcome", outcome ?: "")
        put("hidden", JSONArray(hidden.map { it.name }))
        put("odd", oddText)
        put("loseWinner", loseWinner?.name ?: "")
    }.toString()

    fun restore(json: String) {
        runCatching {
            val o = JSONObject(json)
            balance = o.optString("balance")
            slot = o.optInt("slot")
            road = o.optString("road").takeIf { it.isNotEmpty() }?.let { Road.valueOf(it) }
            cars.clear()
            o.optJSONArray("cars")?.let { a -> for (i in 0 until a.length()) cars.add(Car.valueOf(a.getString(i))) }
            hidden.clear()
            o.optJSONArray("hidden")?.let { a -> for (i in 0 until a.length()) hidden.add(Road.valueOf(a.getString(i))) }
            oddText = o.optString("odd")
            loseWinner = o.optString("loseWinner").takeIf { it.isNotEmpty() }?.let { Car.valueOf(it) }
            outcome = o.optString("outcome").takeIf { it.isNotEmpty() }
            val screen = o.optInt("screen")
            if (ready) {
                analyzing = screen >= 1
                postRace = screen == 2 && outcome != null
            }
        }
    }

    fun reset() {
        road = null; slot = 0; cars.clear(); analyzing = false; showSettings = false; outcome = null
        postRace = false; hidden.clear(); oddText = ""; loseWinner = null
    }
}
