package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.Car
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.logic.Analysis
import com.toprace.tracker.logic.AnalysisEngine
import com.toprace.tracker.logic.Pick

private val Gold = Color(0xFFFFC53D)
private val CellBg = Color(0x33FFFFFF)

@Composable
fun AnalysisScreen(state: SetupState, sprites: SpriteSlicer) {
    val road = state.road ?: return
    val cars = state.cars.toList()
    val result = remember(road, state.slot, cars, state.settings, state.stats, state.rounds, state.maxBet) {
        AnalysisEngine.analyze(road, state.slot, cars, state.settings, state.stats, state.rounds, state.maxBet)
    }
    val pager = rememberPagerState(pageCount = { 2 })

    Column(Modifier.fillMaxSize().padding(top = 2.dp)) {
        Row(Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { state.analyzing = false }.padding(end = 10.dp, top = 2.dp, bottom = 2.dp)) {
                Text("◀ Setup", color = Color.White, fontSize = 12.sp)
            }
            Text(
                road.displayName + "  ·  Slot " + (if (state.slot == 0) "-" else state.slot.toString()),
                color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Text(
                "Max " + "%,.0f".format(state.maxBet) + "   " + (pager.currentPage + 1) + "/2",
                color = Color(0xCCFFFFFF), fontSize = 11.sp,
            )
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            if (page == 0) RankPage(result, sprites) else FinalPage(result, sprites)
        }
        BottomBar(state)
    }
}

@Composable
private fun RankPage(a: Analysis, sprites: SpriteSlicer) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        RankRow("MATH", a.mathRank, sprites, Modifier.weight(1f))
        RankRow("STATIC", a.staticRank, sprites, Modifier.weight(1f))
        RankRow("DATA", a.dataRank, sprites, Modifier.weight(1f))
    }
}

@Composable
private fun RankRow(label: String, cars: List<Car>, sprites: SpriteSlicer, modifier: Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
        cars.forEachIndexed { i, car ->
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(CellBg)) {
                Image(
                    bitmap = sprites.vehicle(car), contentDescription = car.displayName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 11.dp),
                )
                Text(
                    car.displayName, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp),
                )
                Box(
                    Modifier.align(Alignment.TopStart).padding(2.dp).size(16.dp).clip(CircleShape)
                        .background(if (i == 0) Gold else Color(0xFFCBD5E1)),
                    contentAlignment = Alignment.Center,
                ) { Text("${i + 1}", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun FinalPage(a: Analysis, sprites: SpriteSlicer) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        a.picks.forEachIndexed { i, p -> PickRow(i + 1, p, sprites, Modifier.weight(1f)) }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0x33FFC53D)).padding(8.dp),
        ) {
            Text(a.pattern ?: "No pattern yet", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PickRow(rank: Int, p: Pick, sprites: SpriteSlicer, modifier: Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(CellBg).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).background(if (rank == 1) Gold else Color(0xFFCBD5E1)), contentAlignment = Alignment.Center) {
            Text("$rank", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Image(
            bitmap = sprites.vehicle(p.car), contentDescription = p.car.displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier.padding(start = 6.dp).width(84.dp).fillMaxHeight().padding(vertical = 2.dp),
        )
        Column(Modifier.weight(1f).padding(start = 6.dp)) {
            Text(p.car.displayName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Odd " + "%.1f".format(p.odd) + "x", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("BET", color = Color(0x99FFFFFF), fontSize = 9.sp)
            Text("%,.0f".format(p.bet), color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Outcome buttons: open the Post-Race Reveal screen. */
@Composable
private fun BottomBar(state: SetupState) {
    val haptic = LocalHapticFeedback.current
    Row(Modifier.fillMaxWidth().height(36.dp).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf("W1", "W2", "W3", "LOSE").forEach { label ->
            val on = state.outcome == label
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                    .background(
                        when {
                            on -> Gold
                            label == "LOSE" -> Color(0x99EF4444)
                            else -> Color(0x9922C55E)
                        },
                    )
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        state.openPostRace(label)
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (on) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
