package com.toprace.tracker.logic

object BetEngine {
    const val LONGSHOT_ODD = 5.0

    /** 60/30/10, or 50/30/20 when Pick 1 odd is above 5.0x. */
    fun weights(firstOdd: Double): List<Double> =
        if (firstOdd > LONGSHOT_ODD) listOf(0.5, 0.3, 0.2) else listOf(0.6, 0.3, 0.1)

    fun bets(maxBet: Double, firstOdd: Double): List<Double> =
        weights(firstOdd).map { it * maxBet }

    /**
     * Net balance change for a round. All 3 stakes are spent; the winning pick
     * (winnerIndex 0..2, or -1 for LOSE) returns stake x winner odd.
     */
    fun net(bets: List<Double>, winnerIndex: Int, winnerOdd: Double): Double {
        val staked = bets.sum()
        return if (winnerIndex in bets.indices) bets[winnerIndex] * winnerOdd - staked else -staked
    }
}
