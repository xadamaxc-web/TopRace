package com.toprace.tracker.logic

import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.db.LearnedStats

object DataEngine {
    const val PRIOR_K = 10.0

    /** Bayesian win rate per car on this road: prior = 1 / baseOdd, strength k. */
    fun probabilities(road: Road, cars: List<Car>, stats: List<LearnedStats>): Map<Car, Double> {
        val byKey = stats.associateBy { it.carName to it.roadName }
        return cars.associateWith { car ->
            val s = byKey[car.displayName to road.displayName]
            val wins = s?.wins ?: 0
            val total = s?.totalRounds ?: 0
            (wins + PRIOR_K * (1.0 / car.baseOdd)) / (total + PRIOR_K)
        }
    }
}
