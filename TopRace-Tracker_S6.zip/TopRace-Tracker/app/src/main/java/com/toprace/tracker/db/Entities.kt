package com.toprace.tracker.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "rounds")
data class RoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    @ColumnInfo(name = "revealed_road") val revealedRoad: String,
    @ColumnInfo(name = "revealed_slot") val revealedSlot: Int,
    @ColumnInfo(name = "hidden_road_2") val hiddenRoad2: String? = null,
    @ColumnInfo(name = "hidden_road_3") val hiddenRoad3: String? = null,
    val car1: String,
    val car2: String,
    val car3: String,
    val car4: String,
    val car5: String,
    val winner: String? = null,
    @ColumnInfo(name = "winner_odd") val winnerOdd: Double? = null,
    /** "G", "Y" or "R" */
    @ColumnInfo(name = "hud_color") val hudColor: String? = null,
)

@Entity(tableName = "strategy_settings")
data class StrategySettings(
    @PrimaryKey val id: Int = 1,
    val fastRoadBoost: Float = 1.0f,
    val struggleRoadPenalty: Float = 1.0f,
    val slot1Bias: Float = 1.0f,
    val slot2Bias: Float = 1.0f,
    val slot3Bias: Float = 1.0f,
    /** 0 = pure math, 100 = pure data */
    val dataBlend: Int = 50,
)

@Entity(
    tableName = "learned_stats",
    indices = [Index(value = ["carName", "roadName"], unique = true)],
)
data class LearnedStats(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val carName: String,
    val roadName: String,
    val wins: Int = 0,
    val totalRounds: Int = 0,
)
