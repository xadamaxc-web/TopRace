package com.toprace.tracker.logic

import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.db.LearnedStats
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings

data class Pick(val car: Car, val odd: Double, val bet: Double)

data class Analysis(
    val mathRank: List<Car>,
    val staticRank: List<Car>,
    val dataRank: List<Car>,
    val picks: List<Pick>,
    val pattern: String?,
)

object AnalysisEngine {
    fun analyze(
        road: Road,
        slot: Int,
        cars: List<Car>,
        settings: StrategySettings,
        stats: List<LearnedStats>,
        rounds: List<RoundEntity>,
        maxBet: Double,
    ): Analysis {
        val math = MathEngine.scores(road, slot, cars, settings)
        val dataRaw = DataEngine.probabilities(road, cars, stats)
        val data = MathEngine.normalize(dataRaw)

        // no learned rounds for these cars on this road -> pure math
        val hasData = cars.any { c ->
            stats.any { it.carName == c.displayName && it.roadName == road.displayName && it.totalRounds > 0 }
        }
        val w = if (hasData) settings.dataBlend.coerceIn(0, 100) / 100.0 else 0.0
        val final = cars.associateWith { w * data.getValue(it) + (1 - w) * math.getValue(it) }

        val finalTop = rank(cars, final).take(3)
        val bets = BetEngine.bets(maxBet, finalTop.first().baseOdd)
        val picks = finalTop.mapIndexed { i, c -> Pick(c, c.baseOdd, bets[i]) }

        return Analysis(
            mathRank = rank(cars, math),
            staticRank = cars.sortedWith(compareBy<Car> { it.baseOdd }.thenBy { it.ordinal }),
            dataRank = rank(cars, dataRaw),
            picks = picks,
            pattern = PatternEngine.alert(rounds),
        )
    }

    private fun rank(cars: List<Car>, score: Map<Car, Double>): List<Car> =
        cars.sortedWith(
            compareByDescending<Car> { score.getValue(it) }.thenBy { it.baseOdd }.thenBy { it.ordinal },
        )
}
