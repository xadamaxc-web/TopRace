package com.toprace.tracker.logic

import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.Tier

/** "G" / "Y" / "R" for the HUD circles, from the winner on the revealed road. */
object HudEngine {
    fun color(road: Road, winner: Car): String =
        if (road.fast) {
            when (winner.tier) { Tier.FAST -> "G"; Tier.MEDIUM -> "Y" }
        } else {
            when (winner.tier) { Tier.FAST -> "R"; Tier.MEDIUM -> "Y" }
        }
}
