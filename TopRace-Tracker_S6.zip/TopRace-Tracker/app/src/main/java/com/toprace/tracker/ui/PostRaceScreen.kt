package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.logic.BetEngine
import com.toprace.tracker.logic.HudEngine
import kotlinx.coroutines.delay

private val Gold = Color(0xFFFFC53D)
private val CellBg = Color(0x33FFFFFF)

@Composable
fun PostRaceScreen(
    state: SetupState,
    sprites: SpriteSlicer,
    onSave: (RoundEntity, Road, List<Car>, Car?) -> Unit,
) {
    val road = state.road ?: return
    val a = state.currentAnalysis() ?: return
    val idx = state.outcomeIndex()
    val haptic = LocalHapticFeedback.current

    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }

    val bets = a.picks.map { it.bet }
    val winnerCar: Car? = if (idx >= 0) a.picks[idx].car else state.loseWinner
    val odd = state.oddText.toDoubleOrNull()?.takeIf { it > 0 }
    // W1-W3 need the winner odd for the payout; LOSE needs the winner car (odd optional)
    val canSave = if (idx >= 0) odd != null else winnerCar != null
    val net: Double? = if (idx >= 0) odd?.let { BetEngine.net(bets, idx, it) } else BetEngine.net(bets, -1, 0.0)

    Column(Modifier.fillMaxSize().padding(top = 2.dp)) {
        Row(Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { state.postRace = false }.padding(end = 10.dp, top = 2.dp, bottom = 2.dp)) {
                Text("◀ Back", color = Color.White, fontSize = 12.sp)
            }
            Text(
                "POST-RACE  ⏱ $left", color = if (left > 0) Gold else Color(0x99FFFFFF),
                fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Text("${state.outcome}  ·  ${road.displayName}", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // hidden roads
            Column(Modifier.weight(0.45f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Hidden roads ${state.hidden.size}/2", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    items(Road.entries.filter { it != road }) { r ->
                        val n = state.hidden.indexOf(r)
                        val sel = n >= 0
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp))
                                .border(if (sel) 2.dp else 1.dp, if (sel) Gold else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    if (sel) state.hidden.remove(r) else if (state.hidden.size < 2) state.hidden.add(r)
                                },
                        ) {
                            Image(
                                bitmap = sprites.road(r), contentDescription = r.displayName,
                                contentScale = ContentScale.FillWidth, modifier = Modifier.fillMaxWidth(),
                            )
                            if (sel) {
                                Box(
                                    Modifier.align(Alignment.TopStart).padding(2.dp).size(16.dp).clip(CircleShape).background(Gold),
                                    contentAlignment = Alignment.Center,
                                ) { Text("${n + 1}", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            // winner / odd / save
            Column(Modifier.weight(0.55f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    "Winner: " + (winnerCar?.displayName ?: "pick below"),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Winner odd", color = Color.White, fontSize = 11.sp)
                    Box(
                        Modifier.padding(start = 6.dp).weight(1f)
                            .border(1.dp, if (idx >= 0 && odd == null) Color(0xFFEF4444) else Color(0x66FFFFFF), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                    ) {
                        BasicTextField(
                            value = state.oddText,
                            onValueChange = { v -> if (v.all { it.isDigit() || it == '.' }) state.oddText = v },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                            cursorBrush = SolidColor(Color.White),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        )
                    }
                }
                if (idx < 0) {
                    Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        state.cars.filter { c -> a.picks.none { it.car == c } }.forEach { c ->
                            val sel = state.loseWinner == c
                            Box(
                                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                    .background(if (sel) Color(0x55FFC53D) else CellBg)
                                    .border(if (sel) 2.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { state.loseWinner = c },
                            ) {
                                Image(
                                    bitmap = sprites.vehicle(c), contentDescription = c.displayName,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 11.dp),
                                )
                                Text(
                                    c.displayName, color = Color.White, fontSize = 9.sp,
                                    modifier = Modifier.align(Alignment.BottomCenter),
                                )
                            }
                        }
                    }
                }
                Text(
                    "Net: " + (net?.let { (if (it >= 0) "+" else "") + "%,.0f".format(it) } ?: "—"),
                    color = if ((net ?: 0.0) >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                )
                Box(Modifier.weight(1f))
                Box(
                    Modifier.fillMaxWidth().height(38.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (canSave) Color(0xFF22C55E) else Color(0x44FFFFFF))
                        .clickable(enabled = canSave) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val c = state.cars
                            val entity = RoundEntity(
                                timestamp = System.currentTimeMillis(),
                                revealedRoad = road.displayName,
                                revealedSlot = state.slot,
                                hiddenRoad2 = state.hidden.getOrNull(0)?.displayName,
                                hiddenRoad3 = state.hidden.getOrNull(1)?.displayName,
                                car1 = c[0].displayName, car2 = c[1].displayName, car3 = c[2].displayName,
                                car4 = c[3].displayName, car5 = c[4].displayName,
                                winner = winnerCar?.displayName,
                                winnerOdd = odd,
                                hudColor = winnerCar?.let { HudEngine.color(road, it) },
                            )
                            onSave(entity, road, c.toList(), winnerCar)
                            net?.let { state.applyNet(it) }
                            state.reset()
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("SAVE", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
