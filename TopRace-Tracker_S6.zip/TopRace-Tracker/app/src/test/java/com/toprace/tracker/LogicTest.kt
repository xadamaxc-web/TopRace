package com.toprace.tracker

import com.toprace.tracker.db.LearnedStats
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings
import com.toprace.tracker.logic.AnalysisEngine
import com.toprace.tracker.logic.BetEngine
import com.toprace.tracker.logic.HudEngine
import com.toprace.tracker.logic.MathEngine
import com.toprace.tracker.logic.PatternEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LogicTest {

    private fun round(winner: String?) = RoundEntity(
        timestamp = 0, revealedRoad = "Highway", revealedSlot = 1,
        car1 = "Jeep", car2 = "Ape", car3 = "Eagle", car4 = "Flash", car5 = "Thunder",
        winner = winner,
    )

    @Test fun betSplitNormal() {
        val b = BetEngine.bets(1000.0, 2.8)
        assertEquals(600.0, b[0], 1e-9)
        assertEquals(300.0, b[1], 1e-9)
        assertEquals(100.0, b[2], 1e-9)
    }

    @Test fun betSplitLongshot() {
        val b = BetEngine.bets(1000.0, 6.8)
        assertEquals(500.0, b[0], 1e-9)
        assertEquals(300.0, b[1], 1e-9)
        assertEquals(200.0, b[2], 1e-9)
        assertEquals(1000.0, b.sum(), 1e-9)
    }

    @Test fun betSplitBoundaryIsNormal() {
        assertEquals(600.0, BetEngine.bets(1000.0, 5.0)[0], 1e-9)
    }

    @Test fun hiddenRoadsSameTier() {
        assertEquals(setOf(Road.DESERT, Road.EXPRESSWAY), MathEngine.hiddenRoads(Road.HIGHWAY).toSet())
        assertEquals(setOf(Road.BUMPY, Road.POTHOLES), MathEngine.hiddenRoads(Road.MOUNTAIN).toSet())
    }

    @Test fun rawMathFormula() {
        assertEquals(2880.0, MathEngine.rawMath(Road.HIGHWAY, Car.THUNDER), 1e-9)
        assertEquals(1008.0, MathEngine.rawMath(Road.MOUNTAIN, Car.APE), 1e-9)
    }

    @Test fun mathRankOnHighway() {
        val cars = listOf(Car.THUNDER, Car.FLASH, Car.EAGLE, Car.JEEP, Car.APE)
        val a = AnalysisEngine.analyze(Road.HIGHWAY, 0, cars.shuffled(), StrategySettings(), emptyList(), emptyList(), 1000.0)
        assertEquals(listOf(Car.THUNDER, Car.FLASH, Car.EAGLE, Car.APE, Car.JEEP), a.mathRank)
    }

    @Test fun staticRankByBaseOdd() {
        val cars = listOf(Car.WHALE, Car.APE, Car.SHARK, Car.DRAGON, Car.EAGLE)
        val a = AnalysisEngine.analyze(Road.HIGHWAY, 0, cars, StrategySettings(), emptyList(), emptyList(), 1000.0)
        assertEquals(listOf(Car.SHARK, Car.EAGLE, Car.APE, Car.DRAGON, Car.WHALE), a.staticRank)
    }

    @Test fun dataBlendHundredFollowsLearnedWins() {
        val cars = listOf(Car.THUNDER, Car.FLASH, Car.EAGLE, Car.JEEP, Car.APE)
        val stats = listOf(LearnedStats(carName = "Jeep", roadName = "Highway", wins = 10, totalRounds = 10))
        val a = AnalysisEngine.analyze(Road.HIGHWAY, 0, cars, StrategySettings(dataBlend = 100), stats, emptyList(), 1000.0)
        assertEquals(Car.JEEP, a.picks[0].car)
        assertEquals(1000.0, a.picks.sumOf { it.bet }, 1e-9)
    }

    @Test fun streakAlert() {
        val r = listOf(round("Jeep"), round("Jeep"), round("Jeep"), round("Ape"))
        assertEquals("🔥 STREAK: Jeep won last 3", PatternEngine.alert(r))
    }

    @Test fun hotAlert() {
        val r = listOf("Ape", "Jeep", "Ape", "Eagle", "Ape").map { round(it) }
        assertEquals("📈 HOT: Ape won 3 of last 5", PatternEngine.alert(r))
    }

    @Test fun noPattern() {
        assertNull(PatternEngine.alert(emptyList()))
        assertNull(PatternEngine.alert(listOf(round("Ape"), round("Jeep"))))
    }

    @Test fun netSettlement() {
        val bets = listOf(600.0, 300.0, 100.0)
        assertEquals(140.0, BetEngine.net(bets, 1, 3.8), 1e-6)   // 300 x 3.8 - 1000
        assertEquals(-1000.0, BetEngine.net(bets, -1, 0.0), 1e-9)
    }

    @Test fun hudColors() {
        assertEquals("G", HudEngine.color(Road.HIGHWAY, Car.THUNDER))
        assertEquals("Y", HudEngine.color(Road.HIGHWAY, Car.JEEP))
        assertEquals("R", HudEngine.color(Road.MOUNTAIN, Car.WHALE))
        assertEquals("Y", HudEngine.color(Road.MOUNTAIN, Car.APE))
    }

    @Test fun noDataFallsBackToPureMath() {
        val cars = listOf(Car.THUNDER, Car.FLASH, Car.EAGLE, Car.JEEP, Car.APE)
        val a = AnalysisEngine.analyze(Road.HIGHWAY, 0, cars, StrategySettings(dataBlend = 100), emptyList(), emptyList(), 1000.0)
        assertEquals(listOf(Car.THUNDER, Car.FLASH, Car.EAGLE), a.picks.map { it.car })
    }
}
