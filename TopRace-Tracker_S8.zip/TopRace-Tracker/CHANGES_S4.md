# Session 4 - changed files

New: CsvExporter.kt
Edited: db/Daos.kt (RoundDao.all, StatsDao.allNow), MainActivity.kt ([ EXPORT CSV ] button), AndroidManifest.xml (legacy storage permission, API<=28 only)
Learner.kt: unchanged - already counts a win for the winning car regardless of its rank.
Output: Download/toprace_rounds_<stamp>.csv and toprace_stats_<stamp>.csv
