# Session 6
Side-by-side build: applicationId com.toprace.tracker2, app name "TopRace v2". Installs next to the old app (old data untouched). Same fixed debug key, EXPORT CSV included. build.yml unchanged.
