package com.toprace.tracker.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.toprace.tracker.Car
import com.toprace.tracker.Defaults
import com.toprace.tracker.Road
import com.toprace.tracker.db.LearnedStats
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings
import com.toprace.tracker.logic.Analysis
import com.toprace.tracker.logic.AnalysisEngine
import org.json.JSONArray
import org.json.JSONObject

class SetupState {
    var slot by mutableStateOf(0) // 0 = none, 1..3
    var road by mutableStateOf<Road?>(null)
    val cars = mutableStateListOf<Car>() // pick order
    var analyzing by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var minimized by mutableStateOf(false)

    // post-race
    var postRace by mutableStateOf(false)
    val hidden = mutableStateListOf<Road>()
    var winner by mutableStateOf<Car?>(null)

    // loaded from Room by OverlayService
    var settings by mutableStateOf(StrategySettings())
    var stats by mutableStateOf<List<LearnedStats>>(emptyList())
    var rounds by mutableStateOf<List<RoundEntity>>(emptyList()) // newest first

    val ready: Boolean get() = road != null && cars.size == Defaults.PICKS_REQUIRED

    fun toggleCar(car: Car) {
        if (car in cars) cars.remove(car)
        else if (cars.size < Defaults.PICKS_REQUIRED) cars.add(car)
    }

    fun currentAnalysis(): Analysis? {
        val r = road ?: return null
        if (cars.size != Defaults.PICKS_REQUIRED) return null
        return AnalysisEngine.analyze(r, slot, cars.toList(), settings, stats, rounds)
    }

    /** The winner tap on the analysis screen: W1/W2/W3/LOSE for every version follow from it. */
    fun openPostRace(car: Car) {
        winner = car
        hidden.clear()
        postRace = true
    }

    fun toJson(): String = JSONObject().apply {
        put("slot", slot)
        put("road", road?.name ?: "")
        put("cars", JSONArray(cars.map { it.name }))
        put("screen", if (postRace) 2 else if (analyzing) 1 else 0)
        put("hidden", JSONArray(hidden.map { it.name }))
        put("winner", winner?.name ?: "")
    }.toString()

    fun restore(json: String) {
        runCatching {
            val o = JSONObject(json)
            slot = o.optInt("slot")
            road = o.optString("road").takeIf { it.isNotEmpty() }?.let { Road.valueOf(it) }
            cars.clear()
            o.optJSONArray("cars")?.let { a -> for (i in 0 until a.length()) cars.add(Car.valueOf(a.getString(i))) }
            hidden.clear()
            o.optJSONArray("hidden")?.let { a -> for (i in 0 until a.length()) hidden.add(Road.valueOf(a.getString(i))) }
            winner = o.optString("winner").takeIf { it.isNotEmpty() }?.let { Car.valueOf(it) }
            val screen = o.optInt("screen")
            if (ready) {
                analyzing = screen >= 1
                postRace = screen == 2 && winner != null
            }
        }
    }

    fun reset() {
        road = null; slot = 0; cars.clear(); analyzing = false; showSettings = false
        postRace = false; hidden.clear(); winner = null
    }
}
