package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.logic.AnalysisEngine
import com.toprace.tracker.logic.Outcome
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

private val Gold = Color(0xFFFFC53D)
private val CellBg = Color(0x33FFFFFF)

@Composable
fun PostRaceScreen(
    state: SetupState,
    sprites: SpriteSlicer,
    onSave: (RoundEntity, Road, List<Car>, Car?) -> Unit,
) {
    val road = state.road ?: return
    val a = state.currentAnalysis() ?: return
    val winner = state.winner
    val haptic = LocalHapticFeedback.current

    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }

    val ranks: Map<String, Int> = if (winner != null) a.winnerRanks(winner) else emptyMap()

    Column(Modifier.fillMaxSize().padding(top = 2.dp)) {
        Row(Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { state.postRace = false }.padding(end = 10.dp, top = 2.dp, bottom = 2.dp)) {
                Text("◀ Back", color = Color.White, fontSize = 12.sp)
            }
            Text(
                "POST-RACE  ⏱ $left", color = if (left > 0) Gold else Color(0x99FFFFFF),
                fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Text(road.displayName, color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // hidden roads
            Column(Modifier.weight(0.45f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Hidden roads ${state.hidden.size}/2", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    items(Road.entries.filter { it != road }) { r ->
                        val n = state.hidden.indexOf(r)
                        val sel = n >= 0
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp))
                                .border(if (sel) 2.dp else 1.dp, if (sel) Gold else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    if (sel) state.hidden.remove(r) else if (state.hidden.size < 2) state.hidden.add(r)
                                },
                        ) {
                            Image(
                                bitmap = sprites.road(r), contentDescription = r.displayName,
                                contentScale = ContentScale.FillWidth, modifier = Modifier.fillMaxWidth(),
                            )
                            if (sel) {
                                Box(
                                    Modifier.align(Alignment.TopStart).padding(2.dp).size(16.dp).clip(CircleShape).background(Gold),
                                    contentAlignment = Alignment.Center,
                                ) { Text("${n + 1}", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            // winner / per-version results / save
            Column(Modifier.weight(0.55f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    "Winner: " + (winner?.displayName ?: "tap below"),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                )
                Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.cars.toList().forEach { c ->
                        val sel = winner == c
                        Box(
                            Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                .background(if (sel) Color(0x55FFC53D) else CellBg)
                                .border(if (sel) 2.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(6.dp))
                                .clickable { state.winner = c },
                        ) {
                            Image(
                                bitmap = sprites.vehicle(c), contentDescription = c.displayName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 11.dp),
                            )
                            Text(
                                c.displayName, color = Color.White, fontSize = 9.sp,
                                modifier = Modifier.align(Alignment.BottomCenter),
                            )
                        }
                    }
                }
                // W1 / W2 / W3 / LOSE for every version, worked out from the winner tap
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    a.versions.forEach { v ->
                        val rk = ranks[v.name]
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(CellBg).padding(vertical = 3.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(v.name, color = Color(0xCCFFFFFF), fontSize = 8.sp, textAlign = TextAlign.Center)
                            Text(
                                Outcome.code(rk) ?: "—",
                                color = if (rk == null) Color(0x99FFFFFF) else resultColor(rk),
                                fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
                Box(Modifier.weight(1f))
                val canSave = winner != null
                Box(
                    Modifier.fillMaxWidth().height(38.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (canSave) Color(0xFF22C55E) else Color(0x44FFFFFF))
                        .clickable(enabled = canSave) {
                            val w = winner ?: return@clickable
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val c = state.cars
                            val rk = a.winnerRanks(w)
                            val entity = RoundEntity(
                                timestamp = System.currentTimeMillis(),
                                revealedRoad = road.displayName,
                                revealedSlot = state.slot,
                                hiddenRoad2 = state.hidden.getOrNull(0)?.displayName,
                                hiddenRoad3 = state.hidden.getOrNull(1)?.displayName,
                                car1 = c[0].displayName, car2 = c[1].displayName, car3 = c[2].displayName,
                                car4 = c[3].displayName, car5 = c[4].displayName,
                                winner = w.displayName,
                                picksShown = a.picks.joinToString("|") { it.car.displayName },
                                confShown = a.picks.joinToString("|") { (it.confidence * 100).roundToInt().toString() },
                                rankMath = rk[AnalysisEngine.MATH],
                                rankBase = rk[AnalysisEngine.BASE],
                                rankData = rk[AnalysisEngine.DATA],
                                rankBlend = rk[AnalysisEngine.BLEND],
                                rankRecent = rk[AnalysisEngine.RECENT],
                                orderMath = a.orderText(AnalysisEngine.MATH),
                                orderData = a.orderText(AnalysisEngine.DATA),
                                orderBlend = a.orderText(AnalysisEngine.BLEND),
                                orderRecent = a.orderText(AnalysisEngine.RECENT),
                            )
                            onSave(entity, road, c.toList(), w)
                            state.reset()
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("SAVE", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
