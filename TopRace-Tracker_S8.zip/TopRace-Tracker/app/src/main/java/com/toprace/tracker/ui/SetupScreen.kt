package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.view.MotionEvent
import androidx.compose.ui.text.input.KeyboardType
import com.toprace.tracker.Car
import com.toprace.tracker.Defaults
import com.toprace.tracker.Road
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.flow.Flow

private val Panel = Color(0xF00B1530)
private val Gold = Color(0xFFFFC53D)
private val Cell = Color(0x33FFFFFF)

@Composable
fun SetupScreen(
    state: SetupState,
    sprites: SpriteSlicer,
    onDrag: (Float) -> Unit,
    onClose: () -> Unit,
    onSaveSettings: (StrategySettings) -> Unit,
    onSaveRound: (RoundEntity, Road, List<Car>, Car?) -> Unit,
) {
    Column(Modifier.fillMaxSize().background(Panel).padding(6.dp)) {
        TitleBar(state, onDrag, onClose)
        if (state.minimized) {
            // title bar only
        } else if (state.postRace) {
            PostRaceScreen(state, sprites, onSaveRound)
        } else if (state.showSettings) {
            StrategySettingsPanel(state, onSaveSettings)
        } else if (state.analyzing) {
            AnalysisScreen(state, sprites)
        } else {
            TopSection(state, state.rounds)
            Row(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RoadList(state, sprites, Modifier.weight(0.4f).fillMaxHeight())
                VehicleGrid(state, sprites, Modifier.weight(0.6f).fillMaxHeight())
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun TitleBar(state: SetupState, onDrag: (Float) -> Unit, onClose: () -> Unit) {
    val lastY = remember { floatArrayOf(0f, 0f) } // [0] last rawY, [1] total movement
    Row(
        Modifier.fillMaxWidth().height(30.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // drag handle = title area (raw screen Y so the moving window doesn't feed back)
        Box(
            Modifier.weight(1f).fillMaxHeight().pointerInteropFilter { ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lastY[0] = ev.rawY; lastY[1] = 0f; true }
                    MotionEvent.ACTION_MOVE -> {
                        val d = ev.rawY - lastY[0]
                        lastY[1] += kotlin.math.abs(d)
                        onDrag(d)
                        lastY[0] = ev.rawY
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        // long-press (no drag) on the title opens Strategy Settings
                        if (lastY[1] < 12f && ev.eventTime - ev.downTime >= 600) state.showSettings = true
                        true
                    }
                    else -> false
                }
            },
            contentAlignment = Alignment.CenterStart,
        ) {
            Text("TOP RACE  ⠿", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        val ready = state.ready
        Box(
            Modifier.clip(RoundedCornerShape(6.dp))
                .background(if (ready) Color(0xFF22C55E) else Color(0x44FFFFFF))
                .clickable(enabled = ready) { state.analyzing = true }
                .padding(horizontal = 12.dp, vertical = 4.dp),
        ) { Text("ANALYZE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.clickable { state.minimized = !state.minimized }.padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text(if (state.minimized) "▢" else "—", color = Color.White, fontSize = 16.sp)
        }
        Box(Modifier.clickable { onClose() }.padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text("✕", color = Color.White, fontSize = 16.sp)
        }
    }
}

@Composable
private fun TopSection(state: SetupState, last: List<RoundEntity>) {
    Column(Modifier.fillMaxWidth().padding(top = 2.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (s in 1..3) {
                val on = state.slot == s
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(5.dp))
                        .background(if (on) Gold else Cell)
                        .clickable { state.slot = if (on) 0 else s }
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Slot $s", color = if (on) Color.Black else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
        }
        HudGrid(last)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(1 to "W1", 2 to "W2", 3 to "W3", 4 to "LOSE").forEach { (rk, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(resultColor(rk)))
                    Text(label, color = Color(0xCCFFFFFF), fontSize = 9.sp, modifier = Modifier.padding(start = 3.dp))
                }
            }
            Text("(BLEND, newest first)", color = Color(0x99FFFFFF), fontSize = 9.sp)
        }
    }
}

@Composable
private fun HudGrid(last: List<RoundEntity>) {
    // newest first, 2 rows; circle colour = result of the BLEND version for that round
    val perRow = Defaults.HUD_SIZE / 2
    val cells = List(Defaults.HUD_SIZE) { last.getOrNull(it)?.rankBlend }
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (r in 0..1) {
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                for (c in 0 until perRow) {
                    Box(Modifier.size(13.dp).clip(CircleShape).background(resultColor(cells[r * perRow + c])))
                }
            }
        }
    }
}

@Composable
private fun RoadList(state: SetupState, sprites: SpriteSlicer, modifier: Modifier) {
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items(Road.entries) { road ->
            val sel = state.road == road
            Image(
                bitmap = sprites.road(road),
                contentDescription = road.displayName,
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .border(if (sel) 2.dp else 1.dp, if (sel) Gold else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                    .clickable { state.road = road },
            )
        }
    }
}

@Composable
private fun VehicleGrid(state: SetupState, sprites: SpriteSlicer, modifier: Modifier) {
    val haptic = LocalHapticFeedback.current
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (r in 0..2) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (c in 0..2) {
                    val car = Car.entries.first { it.row == r && it.col == c }
                    val idx = state.cars.indexOf(car)
                    val sel = idx >= 0
                    Box(
                        Modifier.weight(1f).fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sel) Color(0x55FFC53D) else Cell)
                            .border(if (sel) 2.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                state.toggleCar(car)
                            },
                    ) {
                        Image(
                            bitmap = sprites.vehicle(car),
                            contentDescription = car.displayName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().padding(bottom = 12.dp, start = 2.dp, end = 2.dp),
                        )
                        Text(
                            car.displayName, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp),
                        )
                        if (sel) {
                            Box(
                                Modifier.align(Alignment.TopStart).padding(2.dp).size(16.dp).clip(CircleShape).background(Gold),
                                contentAlignment = Alignment.Center,
                            ) { Text("${idx + 1}", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}
