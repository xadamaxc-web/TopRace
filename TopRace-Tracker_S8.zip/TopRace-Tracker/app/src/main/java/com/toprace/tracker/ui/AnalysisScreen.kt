package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.logic.Analysis
import com.toprace.tracker.logic.AnalysisEngine
import com.toprace.tracker.logic.Pick
import com.toprace.tracker.logic.VersionRank
import kotlin.math.roundToInt

private val Gold = Color(0xFFFFC53D)
private val CellBg = Color(0x33FFFFFF)

private fun pct(x: Double): String = "${(x * 100).roundToInt()}%"

@Composable
fun AnalysisScreen(state: SetupState, sprites: SpriteSlicer) {
    val road = state.road ?: return
    val cars = state.cars.toList()
    val result = remember(road, state.slot, cars, state.settings, state.stats, state.rounds) {
        AnalysisEngine.analyze(road, state.slot, cars, state.settings, state.stats, state.rounds)
    }
    val pager = rememberPagerState(pageCount = { 2 })

    Column(Modifier.fillMaxSize().padding(top = 2.dp)) {
        Row(Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { state.analyzing = false }.padding(end = 10.dp, top = 2.dp, bottom = 2.dp)) {
                Text("◀ Setup", color = Color.White, fontSize = 12.sp)
            }
            Text(
                road.displayName + "  ·  Slot " + (if (state.slot == 0) "-" else state.slot.toString()),
                color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Text("Tap the winner ▾   " + (pager.currentPage + 1) + "/2", color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            if (page == 0) RankPage(result, sprites) else FinalPage(result, road.displayName, sprites)
        }
        WinnerBar(state, sprites)
    }
}

@Composable
private fun RankPage(a: Analysis, sprites: SpriteSlicer) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        a.versions.forEach { RankRow(it, sprites, Modifier.weight(1f)) }
    }
}

@Composable
private fun RankRow(v: VersionRank, sprites: SpriteSlicer, modifier: Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(v.name, color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(38.dp))
        v.ranked.forEachIndexed { i, car ->
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(CellBg)) {
                Image(
                    bitmap = sprites.vehicle(car), contentDescription = car.displayName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 10.dp),
                )
                Text(
                    car.displayName, color = Color.White, fontSize = 8.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp),
                )
                Box(
                    Modifier.align(Alignment.TopStart).padding(2.dp).size(14.dp).clip(CircleShape)
                        .background(if (i == 0) Gold else Color(0xFFCBD5E1)),
                    contentAlignment = Alignment.Center,
                ) { Text("${i + 1}", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                Text(
                    pct(v.share.getValue(car)), color = Color(0xCCFFFFFF), fontSize = 8.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 3.dp),
                )
            }
        }
    }
}

@Composable
private fun FinalPage(a: Analysis, roadName: String, sprites: SpriteSlicer) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        a.picks.forEachIndexed { i, p -> PickRow(i + 1, p, roadName, sprites, Modifier.weight(1f)) }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0x33FFC53D)).padding(8.dp),
        ) {
            Text(a.pattern ?: "No pattern yet", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PickRow(rank: Int, p: Pick, roadName: String, sprites: SpriteSlicer, modifier: Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(CellBg).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).background(if (rank == 1) Gold else Color(0xFFCBD5E1)), contentAlignment = Alignment.Center) {
            Text("$rank", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Image(
            bitmap = sprites.vehicle(p.car), contentDescription = p.car.displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier.padding(start = 6.dp).width(84.dp).fillMaxHeight().padding(vertical = 2.dp),
        )
        Column(Modifier.weight(1f).padding(start = 6.dp)) {
            Text(p.car.displayName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                if (p.sample < 10) "weak: ${p.sample} rounds on $roadName" else "${p.sample} rounds on $roadName",
                color = Color(0xCCFFFFFF), fontSize = 10.sp,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("CONFIDENCE", color = Color(0x99FFFFFF), fontSize = 8.sp)
            Text(pct(p.confidence), color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** The 5 offered cars as buttons: tap the winner, which opens the Post-Race screen. */
@Composable
private fun WinnerBar(state: SetupState, sprites: SpriteSlicer) {
    val haptic = LocalHapticFeedback.current
    Row(Modifier.fillMaxWidth().height(46.dp).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        state.cars.toList().forEach { car ->
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                    .background(Color(0x9922C55E))
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        state.openPostRace(car)
                    },
            ) {
                Image(
                    bitmap = sprites.vehicle(car), contentDescription = car.displayName,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 10.dp),
                )
                Text(
                    car.displayName, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }
}
