# Session 9 (V2.0)
- Setup page: HUD is now 3 rows x 20 dots with a pager over 5 views (Result BLEND / Winner in MATH order / App confidence / My reorder with sure ring / Winner's final odd).
- Setup page: Copy / Mine toggle. Copy = the 5 offered cars; Mine = my own order of those 5, locked before the winner.
- Analysis page: MINE row under the 5 versions, SURE star, OVERRIDE chip (my #1 differs from BLEND #1).
- Post-race: winner tap, W1/W2/W3/LOSE for every version + MINE, winner's final odd (keys 1 5 . backspace, as in the mock), stake % (20/33/50/75/ALL), SAVE needs winner + odd.
- Road-length overlay (second window, ~20% of screen): drag the handle onto the game's mini-map, tap slot 2/3, tap its road, drag the 2 needles, SAVE or SKIP. SKIP saves the round with the hidden roads and lengths empty. "Open road overlay" in post-race re-opens it.
- DB v4 migration (existing rounds kept): mine_order, mine_rank, override_flag, sure_flag, stake, road_s1..3, len_s1..3. winner_odd (already existed) is filled again.
- CSV: new columns appended at the END: winner_odd, mine_order, mine_rank, override, sure, stake, road_s1..3, len_s1..3.
- hidden_road_2/3 = roads of the two non-revealed slots in slot order.
- versionCode 8 / versionName 2.0.0. Same package and debug key: installs over S8 as an update.
