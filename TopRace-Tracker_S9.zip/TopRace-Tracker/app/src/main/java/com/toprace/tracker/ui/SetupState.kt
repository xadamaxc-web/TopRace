package com.toprace.tracker.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.toprace.tracker.Car
import com.toprace.tracker.Defaults
import com.toprace.tracker.Road
import com.toprace.tracker.db.LearnedStats
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.db.StrategySettings
import com.toprace.tracker.logic.Analysis
import com.toprace.tracker.logic.AnalysisEngine
import org.json.JSONArray
import org.json.JSONObject

class SetupState {
    var slot by mutableStateOf(0) // 0 = none, 1..3
    var road by mutableStateOf<Road?>(null)
    val cars = mutableStateListOf<Car>() // the 5 cars offered, in tap order
    var analyzing by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var minimized by mutableStateOf(false)

    // S9: my own ranking of the offered cars (locked before the winner), SURE star, HUD page
    var mineMode by mutableStateOf(false)
    val mine = mutableStateListOf<Car>()
    var sure by mutableStateOf(false)
    var hudPage by mutableStateOf(0)

    // post-race
    var postRace by mutableStateOf(false)
    var winner by mutableStateOf<Car?>(null)
    val oddTaps = mutableStateListOf<String>() // "1", "5", "."
    var stake by mutableStateOf("") // "", "20", "33", "50", "75", "ALL"

    // S9: road-length overlay. slotRoads[0..2] = road of slot 1..3; lenA/lenB = needle positions 0..1
    val slotRoads = mutableStateListOf<Road?>(null, null, null)
    var lenA by mutableFloatStateOf(0.2f)
    var lenB by mutableFloatStateOf(0.64f)
    var lenSel by mutableStateOf(0) // 0 = none, 2 or 3 = slot being set
    var lenSaved by mutableStateOf(false)
    var overlayDone by mutableStateOf(false) // saved or skipped

    // loaded from Room by OverlayService
    var settings by mutableStateOf(StrategySettings())
    var stats by mutableStateOf<List<LearnedStats>>(emptyList())
    var rounds by mutableStateOf<List<RoundEntity>>(emptyList()) // newest first

    val ready: Boolean get() = road != null && cars.size == Defaults.PICKS_REQUIRED
    val mineComplete: Boolean get() = mine.size == Defaults.PICKS_REQUIRED

    /** The slot whose road was revealed (1 if none was tapped). */
    val lockedSlot: Int get() = if (slot in 1..3) slot else 1

    fun toggleCar(car: Car) {
        if (car in cars) { cars.remove(car); mine.remove(car) }
        else if (cars.size < Defaults.PICKS_REQUIRED) cars.add(car)
    }

    /** In "Mine" mode only the 5 offered cars can be ranked. */
    fun toggleMine(car: Car) {
        if (car !in cars) return
        if (car in mine) mine.remove(car) else if (mine.size < Defaults.PICKS_REQUIRED) mine.add(car)
    }

    /** My #1 differs from the app's BLEND #1. */
    fun isOverride(a: Analysis): Boolean = mineComplete && mine[0] != a.blendRank.first()

    fun oddValue(): Double {
        val i = oddTaps.indexOf(".")
        val whole = (if (i < 0) oddTaps else oddTaps.take(i)).sumOf { it.toInt() }
        val frac = if (i < 0) 0 else oddTaps.drop(i + 1).sumOf { it.toInt() }
        return whole + frac / 10.0
    }

    fun tapOdd(k: String) {
        if (k == "x") { if (oddTaps.isNotEmpty()) oddTaps.removeAt(oddTaps.lastIndex) }
        else if (k != "." || "." !in oddTaps) oddTaps.add(k)
    }

    fun currentAnalysis(): Analysis? {
        val r = road ?: return null
        if (cars.size != Defaults.PICKS_REQUIRED) return null
        return AnalysisEngine.analyze(r, slot, cars.toList(), settings, stats, rounds)
    }

    /** The winner tap on the analysis screen: W1/W2/W3/LOSE for every version follow from it. */
    fun openPostRace(car: Car) {
        winner = car
        postRace = true
    }

    /** Track lengths in whole percent for slot 1..3 (sum 100), or null if never saved. */
    fun lengths(): List<Int>? {
        if (!lenSaved) return null
        val a = Math.round(lenA * 100); val b = Math.round(lenB * 100)
        return listOf(a, b - a, 100 - b)
    }

    fun toJson(): String = JSONObject().apply {
        put("slot", slot)
        put("road", road?.name ?: "")
        put("cars", JSONArray(cars.map { it.name }))
        put("screen", if (postRace) 2 else if (analyzing) 1 else 0)
        put("winner", winner?.name ?: "")
        put("mine", JSONArray(mine.map { it.name }))
        put("sure", sure)
        put("odd", JSONArray(oddTaps.toList()))
        put("stake", stake)
        put("slotRoads", JSONArray(slotRoads.map { it?.name ?: "" }))
        put("lenA", lenA.toDouble()); put("lenB", lenB.toDouble())
        put("lenSaved", lenSaved); put("overlayDone", overlayDone)
    }.toString()

    fun restore(json: String) {
        runCatching {
            val o = JSONObject(json)
            slot = o.optInt("slot")
            road = o.optString("road").takeIf { it.isNotEmpty() }?.let { Road.valueOf(it) }
            cars.clear()
            o.optJSONArray("cars")?.let { a -> for (i in 0 until a.length()) cars.add(Car.valueOf(a.getString(i))) }
            mine.clear()
            o.optJSONArray("mine")?.let { a -> for (i in 0 until a.length()) mine.add(Car.valueOf(a.getString(i))) }
            sure = o.optBoolean("sure")
            oddTaps.clear()
            o.optJSONArray("odd")?.let { a -> for (i in 0 until a.length()) oddTaps.add(a.getString(i)) }
            stake = o.optString("stake")
            o.optJSONArray("slotRoads")?.let { a ->
                for (i in 0 until minOf(3, a.length())) {
                    slotRoads[i] = a.getString(i).takeIf { it.isNotEmpty() }?.let { Road.valueOf(it) }
                }
            }
            lenA = o.optDouble("lenA", 0.2).toFloat(); lenB = o.optDouble("lenB", 0.64).toFloat()
            lenSaved = o.optBoolean("lenSaved"); overlayDone = o.optBoolean("overlayDone")
            winner = o.optString("winner").takeIf { it.isNotEmpty() }?.let { Car.valueOf(it) }
            val screen = o.optInt("screen")
            if (ready) {
                analyzing = screen >= 1
                postRace = screen == 2 && winner != null
            }
        }
    }

    fun reset() {
        road = null; slot = 0; cars.clear(); analyzing = false; showSettings = false
        postRace = false; winner = null
        mineMode = false; mine.clear(); sure = false
        oddTaps.clear(); stake = ""
        for (i in 0..2) slotRoads[i] = null
        lenA = 0.2f; lenB = 0.64f; lenSel = 0; lenSaved = false; overlayDone = false
    }
}
