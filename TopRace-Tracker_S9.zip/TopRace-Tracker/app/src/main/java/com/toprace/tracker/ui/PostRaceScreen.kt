package com.toprace.tracker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.Car
import com.toprace.tracker.Road
import com.toprace.tracker.SpriteSlicer
import com.toprace.tracker.db.RoundEntity
import com.toprace.tracker.logic.AnalysisEngine
import com.toprace.tracker.logic.Outcome
import kotlin.math.roundToInt

private val Gold = Color(0xFFFFC53D)
private val CellBg = Color(0x33FFFFFF)
private val Stakes = listOf("20", "33", "50", "75", "ALL")

@Composable
fun PostRaceScreen(
    state: SetupState,
    sprites: SpriteSlicer,
    onSave: (RoundEntity, Road, List<Car>, Car?) -> Unit,
) {
    val road = state.road ?: return
    val a = state.currentAnalysis() ?: return
    val winner = state.winner
    val haptic = LocalHapticFeedback.current
    val ranks: Map<String, Int> = if (winner != null) a.winnerRanks(winner) else emptyMap()
    val mineRank: Int? = if (winner != null && state.mineComplete) state.mine.indexOf(winner) + 1 else null
    val odd = state.oddValue()
    val lock = state.lockedSlot
    val lens = state.lengths()

    Column(Modifier.fillMaxSize().padding(top = 2.dp)) {
        Row(Modifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { state.postRace = false }.padding(end = 10.dp, top = 2.dp, bottom = 2.dp)) {
                Text("◀ Back", color = Color.White, fontSize = 12.sp)
            }
            Text(
                "POST-RACE" + if (state.sure) "  ★ SURE" else "",
                color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Text(road.displayName, color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // roads + lengths summary (typed on the road overlay) and my stake
            Column(Modifier.weight(0.42f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Roads & lengths", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                for (s in 1..3) {
                    val r = if (s == lock) road else state.slotRoads[s - 1]
                    val len = lens?.get(s - 1)
                    Text(
                        "S$s " + (r?.displayName ?: "???") + (if (len != null) " $len%" else "") + (if (s == lock) " 🔒" else ""),
                        color = Color.White, fontSize = 11.sp,
                    )
                }
                Box(
                    Modifier.clip(RoundedCornerShape(5.dp)).background(Color(0xFF2B8FB3))
                        .clickable { state.overlayDone = false }.padding(horizontal = 8.dp, vertical = 4.dp),
                ) { Text("Open road overlay", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                Text("My stake %", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Stakes.forEach { st ->
                        val on = state.stake == st
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(5.dp))
                                .background(if (on) Gold else CellBg)
                                .clickable { state.stake = if (on) "" else st }.padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(st, color = if (on) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            // winner / per-version results / odd / save
            Column(Modifier.weight(0.58f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.cars.toList().forEach { c ->
                        val sel = winner == c
                        Box(
                            Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                .background(if (sel) Color(0x55FFC53D) else CellBg)
                                .border(if (sel) 2.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(6.dp))
                                .clickable { state.winner = c },
                        ) {
                            Image(
                                bitmap = sprites.vehicle(c), contentDescription = c.displayName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(start = 2.dp, end = 2.dp, bottom = 11.dp),
                            )
                            Text(c.displayName, color = Color.White, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter))
                        }
                    }
                }
                // W1 / W2 / W3 / LOSE for every version + MINE, worked out from the winner tap
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    a.versions.forEach { v -> ResultCell(v.name, ranks[v.name], Modifier.weight(1f)) }
                    ResultCell("MINE", mineRank, Modifier.weight(1f))
                }
                // winner's final odd: the same 1 / 5 / . / backspace keys as the mock
                Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(
                        Modifier.weight(1.6f).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0B0F14))
                            .border(1.5.dp, if (odd >= 8) Color(0xFFF97316) else Gold, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        val txt = if (state.oddTaps.isEmpty()) "odd?" else if ("." in state.oddTaps) "%.1f".format(odd) else odd.roundToInt().toString()
                        Text(txt, color = if (odd >= 8) Color(0xFFF97316) else Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    for (k in listOf("1", "5", ".", "x")) {
                        Box(
                            Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                                .background(if (k == "x") Color(0xFF8A3B3B) else Color(0xFF2E3744))
                                .clickable { state.tapOdd(k) },
                            contentAlignment = Alignment.Center,
                        ) { Text(if (k == "x") "⌫" else k, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                Box(Modifier.weight(1f))
                val canSave = winner != null && odd > 0
                Box(
                    Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (canSave) Color(0xFF22C55E) else Color(0x44FFFFFF))
                        .clickable(enabled = canSave) {
                            val w = winner ?: return@clickable
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val c = state.cars
                            val rk = a.winnerRanks(w)
                            val others = (1..3).filter { it != lock }.map { state.slotRoads[it - 1]?.displayName }
                            val roadAt = { s: Int -> if (s == lock) road.displayName else state.slotRoads[s - 1]?.displayName }
                            val entity = RoundEntity(
                                timestamp = System.currentTimeMillis(),
                                revealedRoad = road.displayName,
                                revealedSlot = state.slot,
                                hiddenRoad2 = others.getOrNull(0),
                                hiddenRoad3 = others.getOrNull(1),
                                car1 = c[0].displayName, car2 = c[1].displayName, car3 = c[2].displayName,
                                car4 = c[3].displayName, car5 = c[4].displayName,
                                winner = w.displayName,
                                winnerOdd = odd,
                                picksShown = a.picks.joinToString("|") { it.car.displayName },
                                confShown = a.picks.joinToString("|") { (it.confidence * 100).roundToInt().toString() },
                                rankMath = rk[AnalysisEngine.MATH],
                                rankBase = rk[AnalysisEngine.BASE],
                                rankData = rk[AnalysisEngine.DATA],
                                rankBlend = rk[AnalysisEngine.BLEND],
                                rankRecent = rk[AnalysisEngine.RECENT],
                                orderMath = a.orderText(AnalysisEngine.MATH),
                                orderData = a.orderText(AnalysisEngine.DATA),
                                orderBlend = a.orderText(AnalysisEngine.BLEND),
                                orderRecent = a.orderText(AnalysisEngine.RECENT),
                                mineOrder = if (state.mineComplete) state.mine.joinToString("|") { it.displayName } else null,
                                mineRank = mineRank,
                                overrideFlag = if (state.isOverride(a)) 1 else 0,
                                sureFlag = if (state.sure) 1 else 0,
                                stake = state.stake.ifEmpty { null },
                                roadS1 = roadAt(1), roadS2 = roadAt(2), roadS3 = roadAt(3),
                                lenS1 = lens?.get(0), lenS2 = lens?.get(1), lenS3 = lens?.get(2),
                            )
                            onSave(entity, road, c.toList(), w)
                            state.reset()
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("SAVE", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun ResultCell(name: String, rank: Int?, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(4.dp)).background(CellBg).padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(name, color = Color(0xCCFFFFFF), fontSize = 8.sp, textAlign = TextAlign.Center)
        Text(
            Outcome.code(rank) ?: "—",
            color = if (rank == null) Color(0x99FFFFFF) else resultColor(rank),
            fontSize = 11.sp, fontWeight = FontWeight.Bold,
        )
    }
}
