package com.toprace.tracker.ui

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.toprace.tracker.Road

private val Gold = Color(0xFFFFC53D)
private val Blue = Color(0xFF2B8FB3)
private const val MIN_SEG = 0.08f

/**
 * The 20% road overlay: put it on the game's mini-map (drag the handle), tap slot 2 or 3,
 * tap its road, drag the two blue needles to the road boundaries, then SAVE (or SKIP).
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun RoadLenOverlay(state: SetupState, onMove: (Float, Float) -> Unit) {
    val road = state.road
    val lock = state.lockedSlot
    val last = remember { floatArrayOf(0f, 0f) }
    val freeSlots = (1..3).filter { it != lock }
    val canSave = freeSlots.all { state.slotRoads[it - 1] != null }

    Column(
        Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)).background(Color(0xE60B1530)).padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(30.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                Modifier.weight(0.7f).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(Blue)
                    .pointerInteropFilter { ev ->
                        when (ev.actionMasked) {
                            MotionEvent.ACTION_DOWN -> { last[0] = ev.rawX; last[1] = ev.rawY; true }
                            MotionEvent.ACTION_MOVE -> {
                                onMove(ev.rawX - last[0], ev.rawY - last[1])
                                last[0] = ev.rawX; last[1] = ev.rawY
                                true
                            }
                            else -> false
                        }
                    },
                contentAlignment = Alignment.Center,
            ) { Text("✥", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(Color(0xFF6B7280))
                    .clickable { state.lenSaved = false; state.lenSel = 0; state.overlayDone = true },
                contentAlignment = Alignment.Center,
            ) { Text("SKIP", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                    .background(if (canSave) Color(0xFF22C55E) else Color(0xFF2E3744))
                    .clickable(enabled = canSave) {
                        if (road != null) state.slotRoads[lock - 1] = road
                        state.lenSaved = true; state.lenSel = 0; state.overlayDone = true
                    },
                contentAlignment = Alignment.Center,
            ) { Text("SAVE", color = if (canSave) Color(0xFF04210F) else Color(0xFF7C8896), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LengthMap(state, lock, Modifier.weight(0.4f).fillMaxHeight())
            Column(Modifier.weight(0.6f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Road.entries.forEach { r ->
                    val sel = state.lenSel in 1..3 && state.slotRoads[state.lenSel - 1] == r
                    Box(
                        Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(4.dp))
                            .background(if (sel) Gold else Color(0x55000000))
                            .border(1.dp, if (state.lenSel == 0) Color(0x66FFFFFF) else Gold, RoundedCornerShape(4.dp))
                            .clickable(enabled = state.lenSel != 0) {
                                state.slotRoads[state.lenSel - 1] = r
                                // jump to the next free slot that still has no road
                                state.lenSel = freeSlots.firstOrNull { it != state.lenSel && state.slotRoads[it - 1] == null } ?: 0
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(r.displayName, color = if (sel) Color.Black else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun LengthMap(state: SetupState, lock: Int, modifier: Modifier) {
    val density = LocalDensity.current
    BoxWithConstraints(modifier) {
        val hPx = with(density) { maxHeight.toPx() }
        val a = state.lenA; val b = state.lenB
        val segs = listOf(a, b - a, 1f - b)
        Column(Modifier.fillMaxSize()) {
            for (i in 0..2) {
                val n = i + 1
                val road = if (n == lock) state.road else state.slotRoads[i]
                val sel = state.lenSel == n
                Box(
                    Modifier.weight(segs[i].coerceAtLeast(0.01f)).fillMaxWidth()
                        .background(if (sel) Color(0x55FFC53D) else Color(0x33FFFFFF))
                        .border(1.5.dp, if (sel) Gold else Color(0x99FFFFFF))
                        .clickable(enabled = n != lock) { state.lenSel = n },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "S$n " + (road?.displayName?.take(4) ?: "???") + (if (n == lock) " 🔒" else "") + "\n" + Math.round(segs[i] * 100) + "%",
                        color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    )
                }
            }
        }
        Needle(maxHeight * a, Modifier) { dy ->
            state.lenA = (state.lenA + dy / hPx).coerceIn(MIN_SEG, state.lenB - MIN_SEG)
        }
        Needle(maxHeight * b, Modifier) { dy ->
            state.lenB = (state.lenB + dy / hPx).coerceIn(state.lenA + MIN_SEG, 1f - MIN_SEG)
        }
    }
}

@Composable
private fun Needle(y: androidx.compose.ui.unit.Dp, modifier: Modifier, onDragY: (Float) -> Unit) {
    Box(modifier.fillMaxWidth().offset(y = y - 11.dp).height(22.dp)) {
        Box(Modifier.align(Alignment.Center).fillMaxWidth().height(2.dp).background(Color.White))
        Box(
            Modifier.align(Alignment.CenterStart).size(22.dp).clip(CircleShape).background(Blue)
                .border(2.dp, Color.White, CircleShape)
                .pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); onDragY(drag.y) } },
        )
    }
}
